module Postgres
  module Conversion
    class ConversionError < Exception; end
  end
end
