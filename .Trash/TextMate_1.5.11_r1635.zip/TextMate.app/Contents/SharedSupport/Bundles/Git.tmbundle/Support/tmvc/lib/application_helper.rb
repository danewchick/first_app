module ApplicationHelper
  include HtmlHelpers
end
